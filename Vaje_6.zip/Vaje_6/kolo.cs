using System;
using System.Collections.Generic;
using System.IO;

namespace KoloApp
{
    class Kolo
    {
        private int StPrestav { get; set; }
        private string Barva { get; set; }
        private string Tip { get; set; }
        private int Leto { get; set; }
        private int StLjudi { get; set; }

        // Osnovni konstruktor
        public Kolo()
        {
            StPrestav = 0;
            Barva = "Črna";
            Tip = "Gorsko";
            Leto = DateTime.Now.Year;
            StLjudi = 1;
        }

        // Konstruktor s poljubnimi parametri
        public Kolo(int stPrestav, string barva, string tip, int leto, int stLjudi)
        {
            StPrestav = stPrestav;
            Barva = barva;
            Tip = tip;
            Leto = leto;
            StLjudi = stLjudi;
        }

        // Metoda za zapis podatkov o kolesu v datoteko
        public static void DodajKoloVDatoteko(string datoteka, Kolo kolo)
        {
            using (StreamWriter sw = File.AppendText(datoteka))
            {
                sw.WriteLine($"{kolo.Leto},{kolo.Barva},{kolo.Tip},{kolo.StPrestav},{kolo.StLjudi}");
            }
        }

        // Metoda za branje podatkov iz datoteke in ustvarjanje tabele koles
        public static List<Kolo> UstvariTabeloKoles(string datoteka)
        {
            List<Kolo> kolesa = new List<Kolo>();

            using (StreamReader sr = File.OpenText(datoteka))
            {
                string vrstica;
                while ((vrstica = sr.ReadLine()) != null)
                {
                    string[] podatki = vrstica.Split(",");
                    Kolo novoKolo = new Kolo(int.Parse(podatki[3]), podatki[1], podatki[2], int.Parse(podatki[0]), int.Parse(podatki[4]));
                    kolesa.Add(novoKolo);
                }
            }

            return kolesa;
        }

        // Metoda za izpis števila koles posamezne barve
        public static void IzpisiSteviloKolesPosamezneBarve(List<Kolo> tabelaKoles)
        {
            Dictionary<string, int> steviloBarv = new Dictionary<string, int>();

            foreach (var kolo in tabelaKoles)
            {
                if (steviloBarv.ContainsKey(kolo.Barva))
                {
                    steviloBarv[kolo.Barva]++;
                }
                else
                {
                    steviloBarv[kolo.Barva] = 1;
                }
            }

            foreach (var kvp in steviloBarv)
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value}");
            }
        }

        // Metoda za prebarvanje koles rumene barve v rdeče
        public static void PrebarvajRumenaVKolo(List<Kolo> tabelaKoles)
        {
            foreach (var kolo in tabelaKoles)
            {
                if (kolo.Barva == "Rumena")
                {
                    kolo.Barva = "Rdeča";
                }
            }
        }

        // Metoda za preštevanje ljudi, ki se lahko peljejo s cestnimi kolesi
        public static int SteviloLjudiCestnaKolesa(List<Kolo> tabelaKoles)
        {
            int stevilo = 0;

            foreach (var kolo in tabelaKoles)
            {
                if (kolo.Tip == "Cestno" && kolo.StLjudi > 1)
                {
                    stevilo += kolo.StLjudi;
                }
            }

            return stevilo;
        }

        // Metoda za odstranjevanje koles starejših od 12 let
        public static void OdstraniStarejsaOd12Let(string vhodnaDatoteka, string izhodnaDatoteka)
        {
            List<string> novaVsebina = new List<string>();

            using (StreamReader sr = File.OpenText(vhodnaDatoteka))
            {
                string vrstica;
                while ((vrstica = sr.ReadLine()) != null)
                {
                    string[] podatki = vrstica.Split(",");
                    int letoIzdelave = int.Parse(podatki[0]);
                    if (DateTime.Now.Year - letoIzdelave <= 12)
                    {
                        novaVsebina.Add(vrstica);
                    }
                }
            }

            File.WriteAllLines(izhodnaDatoteka, novaVsebina);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Sestavi tabelo vsaj 100 koles
            Random random = new Random();
            List<Kolo> tabelaKoles = new List<Kolo>();
            string[] tipi = { "Gorsko", "Cestno", "Treking" };
            string[] barve = { "Zelena", "Bela", "Roza", "Modra", "Oranžna", "Črna", "Rumena", "Vijolična", "Rdeča", "Siva" };

            for (int i = 0; i < 100; i++)
            {
                string tip = tipi[random.Next(tipi.Length)];
                string barva = barve[random.Next(barve.Length)];
                int prestava = random.Next(1, 31);
                int ljudi = random.Next(1, 3);
                int leto = random.Next(1900, 2025);
                Kolo novoKolo = new Kolo(prestava, barva, tip, leto, ljudi);
                tabelaKoles.Add(novoKolo);
            }

            // Zapiši kolesa v datoteko
            foreach (var kolo in tabelaKoles)
            {
                Kolo.DodajKoloVDatoteko("kolesa.txt", kolo);
            }

            // Branje podatkov in ustvarjanje tabele koles
            List<Kolo> tabelaKolesPrebrano = Kolo.UstvariTabeloKoles("kolesa.txt");

            // Izpiši število koles posamezne barve
            Kolo.IzpisiSteviloKolesPosamezneBarve(tabelaKolesPrebrano);

            // Prebarvaj rumena kolesa v rdeča
            Kolo.PrebarvajRumenaVKolo(tabelaKolesPrebrano);

            // Koliko ljudi se lahko hkrati pelje s cestnimi kolesi
            int steviloLjudiCestnaKolesa = Kolo.SteviloLjudiCestnaKolesa(tabelaKolesPrebrano);
            Console.WriteLine($"S cestnim kolesom se lahko hkrati pelje {steviloLjudiCestnaKolesa} ljudi.");

            // Odstrani kolesa starejša od 12 let
            Kolo.OdstraniStarejsaOd12Let("kolesa.txt", "kolesaMlajsaOd12.txt");

            Console.ReadKey();
        }
    }
}
