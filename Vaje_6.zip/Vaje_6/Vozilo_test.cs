using System;

namespace Vozilo_test
{
    public class Vozilo
    {
        private double gorivo;
        private double kapaciteta;
        private double poraba;

        // Konstruktor
        public Vozilo(double kapaciteta, double poraba)
        {
            if (kapaciteta <= 0 || poraba <= 0)
            {
                throw new ArgumentException("Kapaciteta tanka in poraba morata biti pozitivni števili!");
            }

            this.kapaciteta = kapaciteta;
            this.poraba = poraba;
            this.gorivo = kapaciteta; // Polnimo z gorivom ob inicializaciji
        }

        // Lastnost za preostale kilometre
        public double PreostaliKilometri
        {
            get { return gorivo / poraba * 100; }
        }

        // Metoda za polnjenje goriva
        public void Crpalka()
        {
            gorivo = kapaciteta; // Polnimo do polne kapacitete
        }

        // Metoda za vožnjo in preverjanje možnosti potovanja
        public bool LahkoPrevozi(double[] pot)
        {
            double preostaliKilometri = PreostaliKilometri;
            double trenutniKilometri = 0;

            for (int i = 0; i < pot.Length; i++)
            {
                if (pot[i] < 0)
                {
                    throw new ArgumentException("Dolžina poti ne more biti negativna!");
                }

                if (pot[i] == 0)
                {
                    // Preveri ali je naslednji element 0 ali ni
                    if (i < pot.Length - 1 && pot[i + 1] == 0)
                    {
                        throw new ArgumentException("Dva zaporedna elementa z vrednostjo 0 nista dovoljena!");
                    }

                    Crpalka(); // Polnjenje goriva
                }
                else
                {
                    trenutniKilometri += pot[i];
                    double porabaPoti = pot[i] / 100 * poraba; // Poraba goriva za dano pot
                    if (gorivo < porabaPoti) // Preveri ali je dovolj goriva
                    {
                        return false; // Ni dovolj goriva, pot ni izvedljiva
                    }
                    gorivo -= porabaPoti; // Odpeljali smo pot, zmanjšaj gorivo
                }
            }

            return true; // Vozilo lahko prevozi vse poti
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Ustvarjanje vozila
            Vozilo avto = new Vozilo(60, 8); // Kapaciteta 60 litrov, poraba 8 l/100km

            // Testiranje
            double[] pot = { 200, 0, 100, 60, 0, 100 };
            try
            {
                if (avto.LahkoPrevozi(pot))
                {
                    Console.WriteLine("Pot je izvedljiva.");
                    Console.WriteLine($"Na koncu poti bo vozilo imelo še {avto.PreostaliKilometri} km dosega.");
                }
                else
                {
                    Console.WriteLine("Pot ni izvedljiva.");
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Napaka: {ex.Message}");
            }
        }
    }
}
